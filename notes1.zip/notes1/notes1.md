# What is markdown?
-  is a markup language that lets you write plain text documents with a few light weight formatting options.
## What is Git?
-  Version control system. Its a command.
### Github is a website trunk based developer. Hosted Git in cloud or website
#### what is Slack?
-  Slack a messaging app, but built for work.
